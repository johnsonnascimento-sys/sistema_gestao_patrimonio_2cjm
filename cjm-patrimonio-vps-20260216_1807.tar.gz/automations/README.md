# Automations

## Cabecalho

- Modulo: `automations`
- Funcao: especificar fluxos n8n de suporte operacional (geracao de termos e upload).

## Arquivos

- `n8n_gerador_termos_spec.json`: contrato de fluxo para gerar HTML institucional, converter para PDF e salvar no Google Drive.
