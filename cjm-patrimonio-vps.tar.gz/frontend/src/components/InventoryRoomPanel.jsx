/**
 * Modulo: frontend/components
 * Arquivo: InventoryRoomPanel.jsx
 * Funcao no sistema: interface sala a sala com registro de bem de terceiro (Art. 185).
 */
import { useState } from "react";

export default function InventoryRoomPanel({
  rooms,
  inventoryStatus,
  onRegisterThirdParty,
}) {
  const [formByRoom, setFormByRoom] = useState({});

  const setField = (roomId, key, value) => {
    setFormByRoom((prev) => ({
      ...prev,
      [roomId]: {
        ...prev[roomId],
        [key]: value,
      },
    }));
  };

  const submitThirdParty = (room) => {
    const values = formByRoom[room.id] || {};
    if (!values.descricao || !values.detentorExterno) return;
    onRegisterThirdParty({
      descricao: values.descricao,
      detentorExterno: values.detentorExterno,
      sala: room.nome,
      unidadeId: room.unidadeId,
    });
    setFormByRoom((prev) => ({
      ...prev,
      [room.id]: { descricao: "", detentorExterno: "" },
    }));
  };

  return (
    <section className="rounded-2xl border border-white/15 bg-slate-900/55 p-5">
      <h2 className="font-[Space_Grotesk] text-2xl font-semibold">Modo Inventario: Sala a Sala</h2>
      <p className="mt-2 text-sm text-slate-300">
        Registro estruturado das contagens e divergencias por ambiente.
      </p>

      <div className="mt-4 space-y-4">
        {rooms.map((room) => (
          <article key={room.id} className="rounded-xl border border-white/15 bg-slate-950/50 p-4">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <h3 className="font-semibold">{room.nome}</h3>
                <p className="text-xs uppercase tracking-wide text-slate-400">
                  Unidade {room.unidadeId}
                </p>
              </div>
              <button
                type="button"
                disabled={inventoryStatus === "EM_ANDAMENTO"}
                title={
                  inventoryStatus === "EM_ANDAMENTO"
                    ? "Bloqueado durante inventario pelo Art. 183 (AN303_Art183)."
                    : "Transferencia liberada."
                }
                className="rounded-lg border border-rose-300/70 bg-rose-100/10 px-3 py-1.5 text-xs font-semibold text-rose-100 disabled:cursor-not-allowed disabled:opacity-40"
              >
                Transferir bem
              </button>
            </div>

            <ul className="mt-3 space-y-2">
              {room.bens.map((bem) => (
                <li
                  key={bem.tombamento}
                  className="flex items-center justify-between rounded-lg border border-white/10 bg-slate-900/80 px-3 py-2"
                >
                  <div>
                    <p className="text-sm font-medium">{bem.descricao}</p>
                    <p className="text-xs text-slate-400">Tombo: {bem.tombamento}</p>
                  </div>
                  <span className="rounded-full border border-white/20 px-2 py-0.5 text-xs">
                    {bem.status}
                  </span>
                </li>
              ))}
            </ul>

            <div className="mt-4 rounded-lg border border-cyan-200/30 bg-cyan-200/10 p-3">
              <p className="text-sm font-semibold text-cyan-100">Registrar Bem de Terceiro</p>
              <p className="mt-1 text-xs text-cyan-100/80">
                Gera ocorrencia `ENCONTRADO_EM_LOCAL_DIVERGENTE` sem alterar carga durante inventario.
              </p>
              <div className="mt-3 grid gap-2 md:grid-cols-[1.2fr_1fr_auto]">
                <input
                  value={formByRoom[room.id]?.descricao || ""}
                  onChange={(e) => setField(room.id, "descricao", e.target.value)}
                  placeholder="Descricao do bem de terceiro"
                  className="rounded-lg border border-white/20 bg-slate-800 px-3 py-2 text-sm outline-none ring-cyan-200/30 focus:ring"
                />
                <input
                  value={formByRoom[room.id]?.detentorExterno || ""}
                  onChange={(e) => setField(room.id, "detentorExterno", e.target.value)}
                  placeholder="Detentor externo"
                  className="rounded-lg border border-white/20 bg-slate-800 px-3 py-2 text-sm outline-none ring-cyan-200/30 focus:ring"
                />
                <button
                  type="button"
                  onClick={() => submitThirdParty(room)}
                  className="rounded-lg bg-cyan-300 px-3 py-2 text-sm font-semibold text-slate-900 hover:bg-cyan-200"
                >
                  Bem de Terceiro
                </button>
              </div>
            </div>
          </article>
        ))}
      </div>
    </section>
  );
}
