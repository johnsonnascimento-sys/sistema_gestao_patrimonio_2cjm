/**
 * Modulo: frontend/components
 * Arquivo: InventoryRoomPanel.jsx
 * Funcao no sistema: modo inventario (offline-first) com contagens por sala e sincronizacao deterministica.
 */
import { useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import useOfflineSync from "../hooks/useOfflineSync.js";
import {
  atualizarStatusEventoInventario,
  criarEventoInventario,
  listarBens,
  listarEventosInventario,
} from "../services/apiClient.js";

const TOMBAMENTO_RE = /^\d{10}$/;

function formatUnidade(id) {
  if (id === 1) return "1 (1a Aud)";
  if (id === 2) return "2 (2a Aud)";
  if (id === 3) return "3 (Foro)";
  if (id === 4) return "4 (Almox)";
  return String(id || "");
}

function normalizeTombamentoInput(raw) {
  if (raw == null) return "";
  return String(raw).trim().replace(/^\"+|\"+$/g, "");
}

function playAlertBeep() {
  try {
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const o = ctx.createOscillator();
    const g = ctx.createGain();
    o.type = "square";
    o.frequency.value = 880;
    g.gain.value = 0.08;
    o.connect(g);
    g.connect(ctx.destination);
    o.start();
    setTimeout(() => {
      o.stop();
      ctx.close().catch(() => undefined);
    }, 180);
  } catch (_error) {
    // Sem audio em alguns navegadores; nao impede o fluxo.
  }
}

export default function InventoryRoomPanel() {
  const qc = useQueryClient();
  const offline = useOfflineSync();

  const [perfilId, setPerfilId] = useState("");
  const [selectedEventoId, setSelectedEventoId] = useState("");
  const [codigoEvento, setCodigoEvento] = useState("");
  const [unidadeInventariadaId, setUnidadeInventariadaId] = useState("");
  const [encerramentoObs, setEncerramentoObs] = useState("");

  const [unidadeEncontradaId, setUnidadeEncontradaId] = useState("");
  const [salaEncontrada, setSalaEncontrada] = useState("");
  const [scannerValue, setScannerValue] = useState("");
  const [uiError, setUiError] = useState(null);
  const [lastScans, setLastScans] = useState([]);

  const eventosQuery = useQuery({
    queryKey: ["inventarioEventos", "EM_ANDAMENTO"],
    queryFn: async () => {
      const data = await listarEventosInventario("EM_ANDAMENTO");
      return data.items || [];
    },
  });

  const eventoAtivo = useMemo(() => {
    const items = eventosQuery.data || [];
    if (!items.length) return null;
    if (selectedEventoId) return items.find((e) => e.id === selectedEventoId) || items[0];
    return items[0];
  }, [eventosQuery.data, selectedEventoId]);

  const selectedEventoIdFinal = eventoAtivo?.id || "";

  const criarEventoMut = useMutation({
    mutationFn: (payload) => criarEventoInventario(payload),
    onSuccess: async () => {
      setCodigoEvento("");
      setUnidadeInventariadaId("");
      await qc.invalidateQueries({ queryKey: ["inventarioEventos", "EM_ANDAMENTO"] });
    },
  });

  const atualizarStatusMut = useMutation({
    mutationFn: ({ id, payload }) => atualizarStatusEventoInventario(id, payload),
    onSuccess: async () => {
      setEncerramentoObs("");
      await qc.invalidateQueries({ queryKey: ["inventarioEventos", "EM_ANDAMENTO"] });
    },
  });

  const bensSalaQuery = useQuery({
    queryKey: ["bensSala", salaEncontrada],
    enabled: false,
    queryFn: async () => {
      const local = salaEncontrada.trim();
      const data = await listarBens({ localFisico: local, limit: 200, offset: 0, incluirTerceiros: false });
      return data.items || [];
    },
  });

  const bemByTombamento = useMemo(() => {
    const map = new Map();
    for (const b of bensSalaQuery.data || []) {
      if (b.numeroTombamento) map.set(b.numeroTombamento, b);
    }
    return map;
  }, [bensSalaQuery.data]);

  const grouped = useMemo(() => {
    const items = bensSalaQuery.data || [];
    const map = new Map();
    for (const b of items) {
      const key = b.catalogoBemId || "sem-catalogo";
      const group = map.get(key) || {
        catalogoBemId: key,
        catalogoDescricao: b.catalogoDescricao || "Sem catalogo",
        items: [],
      };
      group.items.push(b);
      map.set(key, group);
    }
    return Array.from(map.values()).sort((a, b) => a.catalogoDescricao.localeCompare(b.catalogoDescricao));
  }, [bensSalaQuery.data]);

  const canRegister = Boolean(
    selectedEventoIdFinal &&
      salaEncontrada.trim().length >= 2 &&
      unidadeEncontradaId &&
      Number(unidadeEncontradaId) >= 1 &&
      Number(unidadeEncontradaId) <= 4,
  );

  const onLoadSala = async () => {
    setUiError(null);
    if (salaEncontrada.trim().length < 2) {
      setUiError("Informe a sala/local para baixar o catalogo da sala.");
      return;
    }
    await bensSalaQuery.refetch();
  };

  const onCreateEvento = async (event) => {
    event.preventDefault();
    setUiError(null);

    const perfilIdFinal = perfilId.trim();
    if (!perfilIdFinal) {
      setUiError("Informe um perfilId (UUID) para abrir o evento.");
      return;
    }
    const codigo = codigoEvento.trim();
    if (!codigo) {
      setUiError("Informe um codigoEvento.");
      return;
    }

    const unidadeFinal = unidadeInventariadaId.trim() === "" ? null : Number(unidadeInventariadaId);
    criarEventoMut.mutate({
      codigoEvento: codigo,
      unidadeInventariadaId: unidadeFinal,
      abertoPorPerfilId: perfilIdFinal,
    });
  };

  const onUpdateStatus = async (status) => {
    setUiError(null);
    const perfilIdFinal = perfilId.trim();
    if (!perfilIdFinal) {
      setUiError("Informe um perfilId (UUID) para encerrar/cancelar o evento.");
      return;
    }
    if (!selectedEventoIdFinal) return;

    atualizarStatusMut.mutate({
      id: selectedEventoIdFinal,
      payload: {
        status,
        encerradoPorPerfilId: perfilIdFinal,
        observacoes: encerramentoObs.trim() || undefined,
      },
    });
  };

  const registerScan = async (event) => {
    event.preventDefault();
    setUiError(null);

    if (!canRegister) {
      setUiError("Selecione evento ativo, unidade encontrada e sala antes de registrar.");
      return;
    }

    const numeroTombamento = normalizeTombamentoInput(scannerValue);
    if (!TOMBAMENTO_RE.test(numeroTombamento)) {
      setUiError("Tombamento invalido. Use 10 digitos (ex.: 1290001788).");
      return;
    }

    const unidadeEncontrada = Number(unidadeEncontradaId);
    const bem = bemByTombamento.get(numeroTombamento) || null;
    const divergente = bem ? Number(bem.unidadeDonaId) !== unidadeEncontrada : false;

    // Regra legal: divergencia de local deve gerar ocorrencia sem trocar carga no inventario.
    // Art. 185 (AN303_Art185).
    if (divergente) playAlertBeep();

    const payload = {
      id: crypto.randomUUID(),
      eventoInventarioId: selectedEventoIdFinal,
      unidadeEncontradaId: unidadeEncontrada,
      salaEncontrada: salaEncontrada.trim(),
      encontradoPorPerfilId: perfilId.trim() || null,
      numeroTombamento,
      encontradoEm: new Date().toISOString(),
      observacoes: divergente ? "Detectado como local divergente na UI (alerta)." : null,
    };

    await offline.enqueue(payload);
    setScannerValue("");
    setLastScans((prev) => [
      {
        id: payload.id,
        numeroTombamento,
        divergente,
        unidadeDonaId: bem?.unidadeDonaId || null,
        unidadeEncontradaId: unidadeEncontrada,
        when: new Date().toLocaleString(),
      },
      ...prev,
    ].slice(0, 8));

    if (navigator.onLine) {
      await offline.syncNow();
    }
  };

  return (
    <section className="rounded-2xl border border-white/15 bg-slate-900/55 p-5">
      <header className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h2 className="font-[Space_Grotesk] text-2xl font-semibold">Modo Inventario (offline-first)</h2>
          <p className="mt-2 text-sm text-slate-300">
            Contagens sao persistidas no navegador e sincronizadas com a API quando houver conexao.
          </p>
        </div>
        <div className="text-xs text-slate-300">
          <p>
            Pendentes offline:{" "}
            <span className="font-semibold text-cyan-200">{offline.pendingCount}</span>
          </p>
          <p className="mt-1">
            Conexao:{" "}
            <span className={navigator.onLine ? "text-emerald-300" : "text-amber-300"}>
              {navigator.onLine ? "ONLINE" : "OFFLINE"}
            </span>
          </p>
        </div>
      </header>

      {(uiError || offline.lastError) && (
        <p className="mt-4 rounded-xl border border-rose-300/30 bg-rose-200/10 p-3 text-sm text-rose-200">
          {uiError || offline.lastError}
        </p>
      )}

      <div className="mt-5 grid gap-4 lg:grid-cols-[1.2fr_1fr]">
        <article className="rounded-2xl border border-white/15 bg-slate-950/35 p-4">
          <h3 className="font-semibold">Evento de inventario (EM_ANDAMENTO)</h3>
          <p className="mt-1 text-xs text-slate-300">
            Inventario ativo bloqueia mudanca de carga (Art. 183 - AN303_Art183).
          </p>

          <label className="mt-3 block space-y-1">
            <span className="text-xs text-slate-300">PerfilId (UUID) para abrir/encerrar</span>
            <input
              value={perfilId}
              onChange={(e) => setPerfilId(e.target.value)}
              placeholder="UUID do perfil (crie em Operacoes API)"
              className="w-full rounded-lg border border-white/20 bg-slate-800 px-3 py-2 text-sm"
            />
          </label>

          {eventosQuery.isLoading && <p className="mt-3 text-sm text-slate-300">Carregando eventos...</p>}
          {eventosQuery.error && (
            <p className="mt-3 text-sm text-rose-300">Falha ao listar eventos ativos.</p>
          )}

          {(eventosQuery.data || []).length > 0 ? (
            <div className="mt-3 space-y-3">
              <label className="block space-y-1">
                <span className="text-xs text-slate-300">Selecionar evento</span>
                <select
                  value={selectedEventoIdFinal}
                  onChange={(e) => setSelectedEventoId(e.target.value)}
                  className="w-full rounded-lg border border-white/20 bg-slate-800 px-3 py-2 text-sm"
                >
                  {(eventosQuery.data || []).map((ev) => (
                    <option key={ev.id} value={ev.id}>
                      {ev.codigoEvento} (unidade={ev.unidadeInventariadaId ?? "geral"})
                    </option>
                  ))}
                </select>
              </label>

              <div className="grid gap-2 md:grid-cols-2">
                <button
                  type="button"
                  onClick={() => onUpdateStatus("ENCERRADO")}
                  disabled={atualizarStatusMut.isPending}
                  className="rounded-lg bg-emerald-300 px-4 py-2 text-sm font-semibold text-slate-900 disabled:opacity-50"
                >
                  Encerrar
                </button>
                <button
                  type="button"
                  onClick={() => onUpdateStatus("CANCELADO")}
                  disabled={atualizarStatusMut.isPending}
                  className="rounded-lg bg-amber-300 px-4 py-2 text-sm font-semibold text-slate-900 disabled:opacity-50"
                >
                  Cancelar
                </button>
              </div>

              <label className="block space-y-1">
                <span className="text-xs text-slate-300">Observacoes de encerramento (opcional)</span>
                <textarea
                  value={encerramentoObs}
                  onChange={(e) => setEncerramentoObs(e.target.value)}
                  className="min-h-20 w-full rounded-lg border border-white/20 bg-slate-800 px-3 py-2 text-sm"
                />
              </label>
            </div>
          ) : (
            <form onSubmit={onCreateEvento} className="mt-3 space-y-3">
              <p className="text-sm text-slate-300">
                Nenhum evento ativo. Abra um evento para iniciar o inventario.
              </p>
              <label className="block space-y-1">
                <span className="text-xs text-slate-300">codigoEvento</span>
                <input
                  value={codigoEvento}
                  onChange={(e) => setCodigoEvento(e.target.value)}
                  placeholder="Ex.: INV_2026_02_16_1AAUD"
                  className="w-full rounded-lg border border-white/20 bg-slate-800 px-3 py-2 text-sm"
                />
              </label>
              <label className="block space-y-1">
                <span className="text-xs text-slate-300">unidadeInventariadaId (1..4) ou vazio (geral)</span>
                <input
                  type="number"
                  min="1"
                  max="4"
                  value={unidadeInventariadaId}
                  onChange={(e) => setUnidadeInventariadaId(e.target.value)}
                  className="w-full rounded-lg border border-white/20 bg-slate-800 px-3 py-2 text-sm"
                />
              </label>
              <button
                type="submit"
                disabled={criarEventoMut.isPending}
                className="rounded-lg bg-cyan-300 px-4 py-2 text-sm font-semibold text-slate-900 disabled:opacity-50"
              >
                {criarEventoMut.isPending ? "Abrindo..." : "Abrir evento"}
              </button>
            </form>
          )}
        </article>

        <article className="rounded-2xl border border-white/15 bg-slate-950/35 p-4">
          <h3 className="font-semibold">Sala e scanner</h3>
          <p className="mt-1 text-xs text-slate-300">
            Baixe os bens da sala e registre tombamentos. Divergencias tocam alerta e viram ocorrencia (Art. 185).
          </p>

          <div className="mt-3 grid gap-3 md:grid-cols-2">
            <label className="space-y-1">
              <span className="text-xs text-slate-300">Unidade encontrada (1..4)</span>
              <select
                value={unidadeEncontradaId}
                onChange={(e) => setUnidadeEncontradaId(e.target.value)}
                className="w-full rounded-lg border border-white/20 bg-slate-800 px-3 py-2 text-sm"
              >
                <option value="">Selecione</option>
                <option value="1">{formatUnidade(1)}</option>
                <option value="2">{formatUnidade(2)}</option>
                <option value="3">{formatUnidade(3)}</option>
                <option value="4">{formatUnidade(4)}</option>
              </select>
            </label>
            <label className="space-y-1 md:col-span-2">
              <span className="text-xs text-slate-300">Sala/local (usa local_fisico)</span>
              <input
                value={salaEncontrada}
                onChange={(e) => setSalaEncontrada(e.target.value)}
                placeholder="Ex.: Sala 101, 1a Aud, Almox..."
                className="w-full rounded-lg border border-white/20 bg-slate-800 px-3 py-2 text-sm"
              />
            </label>
            <div className="flex flex-wrap items-center gap-2 md:col-span-2">
              <button
                type="button"
                onClick={onLoadSala}
                disabled={bensSalaQuery.isFetching}
                className="rounded-lg bg-amber-300 px-4 py-2 text-sm font-semibold text-slate-900 disabled:opacity-50"
              >
                {bensSalaQuery.isFetching ? "Carregando..." : "Baixar catalogo da sala"}
              </button>
              <button
                type="button"
                onClick={() => offline.syncNow()}
                disabled={offline.isSyncing || offline.pendingCount === 0}
                className="rounded-lg border border-white/25 px-4 py-2 text-sm hover:bg-white/10 disabled:opacity-50"
              >
                {offline.isSyncing ? "Sincronizando..." : "Sincronizar agora"}
              </button>
            </div>
          </div>

          <form onSubmit={registerScan} className="mt-4 grid gap-2 md:grid-cols-[1fr_auto]">
            <input
              value={scannerValue}
              onChange={(e) => setScannerValue(e.target.value)}
              placeholder="Bipar tombamento (10 digitos) e pressionar Enter"
              inputMode="numeric"
              pattern="\\d{10}"
              maxLength={18}
              className="rounded-lg border border-white/20 bg-slate-800 px-3 py-2 text-sm"
            />
            <button
              type="submit"
              disabled={!canRegister}
              className="rounded-lg bg-cyan-300 px-4 py-2 text-sm font-semibold text-slate-900 disabled:opacity-50"
            >
              Registrar
            </button>
          </form>

          {lastScans.length > 0 && (
            <div className="mt-4 space-y-2">
              <p className="text-xs uppercase tracking-widest text-slate-400">Ultimos registros</p>
              {lastScans.map((s) => (
                <div key={s.id} className="rounded-lg border border-white/10 bg-slate-900/60 px-3 py-2 text-xs">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <span className="font-mono text-slate-100">{s.numeroTombamento}</span>
                    <span className="text-slate-300">{s.when}</span>
                  </div>
                  <div className="mt-1 text-slate-300">
                    {s.divergente ? (
                      <span className="text-amber-200">
                        Divergente: dono={formatUnidade(Number(s.unidadeDonaId))} encontrado={formatUnidade(Number(s.unidadeEncontradaId))}
                      </span>
                    ) : (
                      <span className="text-emerald-200">Conforme</span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </article>
      </div>

      <article className="mt-5 rounded-2xl border border-white/15 bg-slate-950/30 p-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h3 className="font-semibold">Bens da sala (agrupado por catalogo)</h3>
          <p className="text-xs text-slate-300">
            Itens carregados: <span className="font-semibold text-slate-100">{(bensSalaQuery.data || []).length}</span>
          </p>
        </div>

        {bensSalaQuery.error && (
          <p className="mt-3 text-sm text-rose-300">Falha ao carregar bens para este local.</p>
        )}
        {!bensSalaQuery.isFetching && (bensSalaQuery.data || []).length === 0 && (
          <p className="mt-3 text-sm text-slate-300">
            Carregue uma sala para ver o catalogo agrupado (usa filtro por <code className="px-1">local_fisico</code>).
          </p>
        )}

        <div className="mt-3 space-y-2">
          {grouped.map((g) => (
            <details key={g.catalogoBemId} className="rounded-xl border border-white/10 bg-slate-900/55 p-3">
              <summary className="cursor-pointer select-none text-sm font-semibold text-slate-100">
                {g.catalogoDescricao} ({g.items.length})
              </summary>
              <div className="mt-3 overflow-auto rounded-lg border border-white/10">
                <table className="min-w-full text-left text-xs">
                  <thead className="bg-slate-900/70 text-[11px] uppercase tracking-wider text-slate-300">
                    <tr>
                      <th className="px-3 py-2">Tombo</th>
                      <th className="px-3 py-2">Unidade (carga)</th>
                      <th className="px-3 py-2">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/10 bg-slate-950/20">
                    {g.items.slice(0, 200).map((b) => (
                      <tr key={b.id} className="hover:bg-white/5">
                        <td className="px-3 py-2 font-mono">{b.numeroTombamento || "-"}</td>
                        <td className="px-3 py-2 text-slate-200">{formatUnidade(Number(b.unidadeDonaId))}</td>
                        <td className="px-3 py-2 text-slate-300">{b.status}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </details>
          ))}
        </div>
      </article>
    </section>
  );
}
